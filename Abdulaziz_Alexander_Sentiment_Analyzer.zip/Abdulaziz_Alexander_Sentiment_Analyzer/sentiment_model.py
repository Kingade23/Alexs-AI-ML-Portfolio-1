import re, joblib, nltk, pathlib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from nltk.corpus import stopwords
import sample_data as sd

MODEL_FILE = pathlib.Path(__file__).parent / "sentiment_model.joblib"
VEC_FILE = pathlib.Path(__file__).parent / "sentiment_vectorizer.joblib"

nltk.download('stopwords', quiet=True)
STOPWORDS = set(stopwords.words('english'))

def clean_text(s):
    s = re.sub(r'[^a-zA-Z0-9\s]', '', s.lower())
    return ' '.join(w for w in s.split() if w not in STOPWORDS)

class SentimentAnalyzer:
    def __init__(self):
        self.vec = TfidfVectorizer(max_features=2000)
        self.model = LogisticRegression(max_iter=1000)

    def fit(self, texts, labels):
        X = self.vec.fit_transform([clean_text(t) for t in texts])
        X_train, X_val, y_train, y_val = train_test_split(X, labels, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)
        preds = self.model.predict(X_val)
        print('Accuracy:', accuracy_score(y_val, preds))

    def predict(self, text):
        X = self.vec.transform([clean_text(text)])
        prob = self.model.predict_proba(X)[0][1]
        label = self.model.predict(X)[0]
        return prob, label

    def save(self):
        joblib.dump(self.model, MODEL_FILE)
        joblib.dump(self.vec, VEC_FILE)

    def load(self):
        self.model = joblib.load(MODEL_FILE)
        self.vec = joblib.load(VEC_FILE)

if __name__ == "__main__":
    df = sd.get_dataframe()
    sa = SentimentAnalyzer()
    sa.fit(df['text'], df['label'])
    sa.save()

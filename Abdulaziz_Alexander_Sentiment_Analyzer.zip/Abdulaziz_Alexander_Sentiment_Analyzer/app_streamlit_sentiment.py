import streamlit as st
import sample_data as sd
from sentiment_model import SentimentAnalyzer

st.title("Customer Review Sentiment Analyzer")
st.write("Enter a review and see if it is Positive or Negative.")

sa = SentimentAnalyzer()
try:
    sa.load()
except:
    st.info("Training model on sample data...")
    df = sd.get_dataframe()
    sa.fit(df['text'], df['label'])
    sa.save()

review = st.text_area("Type a review:", "This product is great!")

if st.button("Analyze"):
    prob, label = sa.predict(review)
    if label == 1:
        st.success(f"Positive review (confidence {prob:.2f})")
    else:
        st.error(f"Negative review (confidence {prob:.2f})")

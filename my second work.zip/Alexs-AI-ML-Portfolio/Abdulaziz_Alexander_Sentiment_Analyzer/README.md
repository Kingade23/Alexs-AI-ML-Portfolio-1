# Abdulaziz Alexander Sentiment Analyzer

### 👨‍💻 Author: Abdulaziz Alexander Abdulganiyu
### 🌐 GitHub: [Kingade23](https://github.com/Kingade23)

---

## 🧠 Overview
This project demonstrates a **Customer Review Sentiment Analyzer** built using **Python, Scikit-learn, and Streamlit**.
It predicts whether a given review expresses **positive** or **negative** sentiment, and highlights key words that influenced the prediction.

---

## ⚙️ Features
- Real-world **Natural Language Processing (NLP)** example  
- Uses **TF-IDF** vectorization + **Logistic Regression**
- Simple explainability — highlights top words influencing predictions
- Deployable demo app with **Streamlit**

---

## 🚀 How to Run

1️⃣ Create a virtual environment and install dependencies:
```bash
python -m venv venv
source venv/bin/activate  # on Mac/Linux
venv\Scripts\activate   # on Windows
pip install -r requirements.txt
```

2️⃣ Train and save model (optional — Streamlit will auto-train on first run):
```bash
python sentiment_model.py
```

3️⃣ Launch the Streamlit web app:
```bash
streamlit run app_streamlit_sentiment.py
```

4️⃣ Paste a review or choose a sample, click *Analyze*, and see predictions with highlighted words.

---

## 📁 Project Structure
```
Abdulaziz_Alexander_Sentiment_Analyzer/
│
├── README.md
├── sample_data.py
├── sentiment_model.py
├── app_streamlit_sentiment.py
└── requirements.txt
```

---

## 🧩 Next Improvements
- Add larger real-world datasets
- Integrate transformer-based models (BERT / DistilBERT)
- Deploy the Streamlit app to a live platform (Streamlit Cloud or HuggingFace Spaces)

---

## 📚 About Abdulaziz Alexander Abdulganiyu
Passionate AI and Machine Learning specialist skilled in NLP, computer vision, and model deployment.  
Always exploring innovative data-driven solutions to real-world problems.  

🔗 GitHub: [Kingade23](https://github.com/Kingade23)  
🔗 LinkedIn: (add link here later)

import pandas as pd

SAMPLES = [
    {"text": "This product is amazing! Fast shipping and great quality.", "label": 1},
    {"text": "Terrible experience. Item arrived broken.", "label": 0},
    {"text": "Excellent value for money — would buy again.", "label": 1},
    {"text": "Not worth it. Very disappointed.", "label": 0}
]

def get_dataframe():
    return pd.DataFrame(SAMPLES)
